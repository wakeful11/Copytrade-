export const RPC_ENDPOINT="https://mainnet.helius-rpc.com/?api-key="
export const RPC_WEBSOCKET_ENDPOINT='wss://atlas-mainnet.helius-rpc.com/?api-key='
export const JUP_AGGREGATOR=process.env.JUP_AGGREGATOR;
export const TARGET_WALLET=process.env.TARGET_WALLET
export const MAXIMUM_BUY_AMOUNT=process.env.MAXIMUM_BUY_AMOUNT